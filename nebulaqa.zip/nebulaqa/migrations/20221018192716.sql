-- create "country" table
CREATE TABLE "public"."country" ("country_id" serial NOT NULL, "country" character varying(50) NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("country_id"));
-- create "city" table
CREATE TABLE "public"."city" ("city_id" serial NOT NULL, "city" character varying(50) NOT NULL, "country_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("city_id"), CONSTRAINT "fk_city" FOREIGN KEY ("country_id") REFERENCES "public"."country" ("country_id") ON UPDATE NO ACTION ON DELETE NO ACTION);
-- create index "idx_fk_country_id" to table: "city"
CREATE INDEX "idx_fk_country_id" ON "public"."city" ("country_id");
-- create "address" table
CREATE TABLE "public"."address" ("address_id" serial NOT NULL, "address" character varying(50) NOT NULL, "address2" character varying(50) NULL, "district" character varying(20) NOT NULL, "city_id" smallint NOT NULL, "postal_code" character varying(10) NULL, "phone" character varying(20) NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("address_id"), CONSTRAINT "fk_address_city" FOREIGN KEY ("city_id") REFERENCES "public"."city" ("city_id") ON UPDATE NO ACTION ON DELETE NO ACTION);
-- create index "idx_fk_city_id" to table: "address"
CREATE INDEX "idx_fk_city_id" ON "public"."address" ("city_id");
-- create "customer" table
CREATE TABLE "public"."customer" ("customer_id" serial NOT NULL, "store_id" smallint NOT NULL, "first_name" character varying(45) NOT NULL, "last_name" character varying(45) NOT NULL, "email" character varying(50) NULL, "address_id" smallint NOT NULL, "activebool" boolean NOT NULL DEFAULT true, "create_date" date NOT NULL DEFAULT ('now'::text)::date, "last_update" timestamp NULL DEFAULT now(), "active" integer NULL, PRIMARY KEY ("customer_id"), CONSTRAINT "customer_address_id_fkey" FOREIGN KEY ("address_id") REFERENCES "public"."address" ("address_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_fk_address_id" to table: "customer"
CREATE INDEX "idx_fk_address_id" ON "public"."customer" ("address_id");
-- create index "idx_fk_store_id" to table: "customer"
CREATE INDEX "idx_fk_store_id" ON "public"."customer" ("store_id");
-- create index "idx_last_name" to table: "customer"
CREATE INDEX "idx_last_name" ON "public"."customer" ("last_name");
-- create "language" table
CREATE TABLE "public"."language" ("language_id" serial NOT NULL, "name" character(20) NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("language_id"));
-- create enum type "mpaa_rating"
CREATE TYPE "public"."mpaa_rating" AS ENUM ('G', 'PG', 'PG-13', 'R', 'NC-17');
-- create "film" table
CREATE TABLE "public"."film" ("film_id" serial NOT NULL, "title" character varying(255) NOT NULL, "description" text NULL, "release_year" integer NULL, "language_id" smallint NOT NULL, "rental_duration" smallint NOT NULL DEFAULT 3, "rental_rate" numeric(4,2) NOT NULL DEFAULT 4.99, "length" smallint NULL, "replacement_cost" numeric(5,2) NOT NULL DEFAULT 19.99, "rating" "public"."mpaa_rating" NULL DEFAULT 'G', "last_update" timestamp NOT NULL DEFAULT now(), "special_features" text[] NULL, PRIMARY KEY ("film_id"), CONSTRAINT "film_language_id_fkey" FOREIGN KEY ("language_id") REFERENCES "public"."language" ("language_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_fk_language_id" to table: "film"
CREATE INDEX "idx_fk_language_id" ON "public"."film" ("language_id");
-- create index "idx_title" to table: "film"
CREATE INDEX "idx_title" ON "public"."film" ("title");
-- create "inventory" table
CREATE TABLE "public"."inventory" ("inventory_id" serial NOT NULL, "film_id" smallint NOT NULL, "store_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("inventory_id"), CONSTRAINT "inventory_film_id_fkey" FOREIGN KEY ("film_id") REFERENCES "public"."film" ("film_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_store_id_film_id" to table: "inventory"
CREATE INDEX "idx_store_id_film_id" ON "public"."inventory" ("store_id", "film_id");
-- create "staff" table
CREATE TABLE "public"."staff" ("staff_id" serial NOT NULL, "first_name" character varying(45) NOT NULL, "last_name" character varying(45) NOT NULL, "address_id" smallint NOT NULL, "email" character varying(50) NULL, "store_id" smallint NOT NULL, "active" boolean NOT NULL DEFAULT true, "username" character varying(16) NOT NULL, "password" character varying(40) NULL, "last_update" timestamp NOT NULL DEFAULT now(), "picture" bytea NULL, PRIMARY KEY ("staff_id"), CONSTRAINT "staff_address_id_fkey" FOREIGN KEY ("address_id") REFERENCES "public"."address" ("address_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create "rental" table
CREATE TABLE "public"."rental" ("rental_id" serial NOT NULL, "rental_date" timestamp NOT NULL, "inventory_id" integer NOT NULL, "customer_id" smallint NOT NULL, "return_date" timestamp NULL, "staff_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("rental_id"), CONSTRAINT "rental_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customer" ("customer_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "rental_inventory_id_fkey" FOREIGN KEY ("inventory_id") REFERENCES "public"."inventory" ("inventory_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "rental_staff_id_key" FOREIGN KEY ("staff_id") REFERENCES "public"."staff" ("staff_id") ON UPDATE NO ACTION ON DELETE NO ACTION);
-- create index "idx_fk_inventory_id" to table: "rental"
CREATE INDEX "idx_fk_inventory_id" ON "public"."rental" ("inventory_id");
-- create index "idx_unq_rental_rental_date_inventory_id_customer_id" to table: "rental"
CREATE UNIQUE INDEX "idx_unq_rental_rental_date_inventory_id_customer_id" ON "public"."rental" ("rental_date", "inventory_id", "customer_id");
-- create "actor" table
CREATE TABLE "public"."actor" ("actor_id" serial NOT NULL, "first_name" character varying(45) NOT NULL, "last_name" character varying(45) NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("actor_id"));
-- create index "idx_actor_last_name" to table: "actor"
CREATE INDEX "idx_actor_last_name" ON "public"."actor" ("last_name");
-- create "film_actor" table
CREATE TABLE "public"."film_actor" ("actor_id" smallint NOT NULL, "film_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("actor_id", "film_id"), CONSTRAINT "film_actor_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."actor" ("actor_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "film_actor_film_id_fkey" FOREIGN KEY ("film_id") REFERENCES "public"."film" ("film_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_fk_film_id" to table: "film_actor"
CREATE INDEX "idx_fk_film_id" ON "public"."film_actor" ("film_id");
-- create "category" table
CREATE TABLE "public"."category" ("category_id" serial NOT NULL, "name" character varying(25) NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("category_id"));
-- create "film_category" table
CREATE TABLE "public"."film_category" ("film_id" smallint NOT NULL, "category_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("film_id", "category_id"), CONSTRAINT "film_category_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."category" ("category_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "film_category_film_id_fkey" FOREIGN KEY ("film_id") REFERENCES "public"."film" ("film_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create "payment" table
CREATE TABLE "public"."payment" ("payment_id" serial NOT NULL, "customer_id" smallint NOT NULL, "staff_id" smallint NOT NULL, "rental_id" integer NOT NULL, "amount" numeric(5,2) NOT NULL, "payment_date" timestamp NOT NULL, PRIMARY KEY ("payment_id"), CONSTRAINT "payment_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customer" ("customer_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "payment_rental_id_fkey" FOREIGN KEY ("rental_id") REFERENCES "public"."rental" ("rental_id") ON UPDATE CASCADE ON DELETE SET NULL, CONSTRAINT "payment_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "public"."staff" ("staff_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_fk_customer_id" to table: "payment"
CREATE INDEX "idx_fk_customer_id" ON "public"."payment" ("customer_id");
-- create index "idx_fk_rental_id" to table: "payment"
CREATE INDEX "idx_fk_rental_id" ON "public"."payment" ("rental_id");
-- create index "idx_fk_staff_id" to table: "payment"
CREATE INDEX "idx_fk_staff_id" ON "public"."payment" ("staff_id");
-- create "store" table
CREATE TABLE "public"."store" ("store_id" serial NOT NULL, "manager_staff_id" smallint NOT NULL, "address_id" smallint NOT NULL, "last_update" timestamp NOT NULL DEFAULT now(), PRIMARY KEY ("store_id"), CONSTRAINT "store_address_id_fkey" FOREIGN KEY ("address_id") REFERENCES "public"."address" ("address_id") ON UPDATE CASCADE ON DELETE RESTRICT, CONSTRAINT "store_manager_staff_id_fkey" FOREIGN KEY ("manager_staff_id") REFERENCES "public"."staff" ("staff_id") ON UPDATE CASCADE ON DELETE RESTRICT);
-- create index "idx_unq_manager_staff_id" to table: "store"
CREATE UNIQUE INDEX "idx_unq_manager_staff_id" ON "public"."store" ("manager_staff_id");
